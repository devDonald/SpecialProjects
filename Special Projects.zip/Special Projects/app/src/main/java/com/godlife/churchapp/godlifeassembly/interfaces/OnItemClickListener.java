package com.godlife.churchapp.godlifeassembly.interfaces;

import com.godlife.churchapp.godlifeassembly.models.YoutubeDataModel;

public interface OnItemClickListener {
    void onItemClick(YoutubeDataModel item);

}